class CreateTables < ActiveRecord::Migration
  def up
  	sql = <<'SQL'
CREATE TABLE airports(
          ID INTEGER PRIMARY KEY,
          name STRING,
          city STRING,
          lat DOUBLE,
          lon DOUBLE);
CREATE TABLE cities (
          id INTEGER PRIMARY KEY,
          county_id INTEGER,
          state_id INTEGER,
          name STRING,
          lat DOUBLE,
          lon DOUBLE
        );
CREATE TABLE city_airport_dist (city_id INTEGER, airport_id INTEGER, distance DOUBLE);
CREATE TABLE city_military_base_dist (city_id INTEGER, military_base_id INTEGER, distance DOUBLE);
CREATE TABLE city_weather_station_dist (city_id INTEGER, weather_station_id INTEGER, distance DOUBLE);
CREATE TABLE counties (
          id INTEGER PRIMARY KEY,
          state_id INTEGER,
          name STRING,
          population_density DOUBLE,
          lat DOUBLE,
          lon DOUBLE
        );
CREATE TABLE military_bases(
          ID INTEGER PRIMARY KEY,
          name STRING,
          lat DOUBLE,
          lon DOUBLE
        );
CREATE TABLE shapes (
          id INTEGER PRIMARY KEY,
          name STRING,
          type_id INTEGER
        );
CREATE TABLE sighting_types (
          id INTEGER PRIMARY KEY,
          name STRING,
          img_name STRING,
          color INTEGER
        );
CREATE TABLE sightings (
          id INTEGER PRIMARY KEY,
          city_id INTEGER,
          shape_id INTEGER,
          summary_description STRING,
          full_description STRING, 
          occurred_at TIMESTAMP,
          reported_at TIMESTAMP,
          posted_at TIMESTAMP,
          temperature INTEGER,
          weather_conditions STRING
        );
CREATE TABLE states (
          id INTEGER PRIMARY KEY, 
          name_abbreviation STRING, 
          name STRING,
          lat DOUBLE,
          lon DOUBLE
        );
CREATE TABLE weather_stations(
          id INTEGER PRIMARY KEY,
          name STRING,
          key STRING,
          state_id INTEGER,
          lat DOUBLE,
          lon DOUBLE
        );
CREATE INDEX airports_index_id ON airports(id);
CREATE INDEX airports_index_lat_lon ON airports(lat, lon);
CREATE INDEX cadist_index_city_id on city_airport_dist(city_id);
CREATE INDEX cities_index_county_id ON cities(county_id);
CREATE INDEX cities_index_id ON cities(id);
CREATE INDEX cities_index_lat_lon ON cities(lat, lon);
CREATE UNIQUE INDEX cities_index_name_state_id ON cities(name,state_id);
CREATE INDEX cities_index_state_id ON cities(state_id);
CREATE INDEX city_military_base_dist_index_city_id on city_military_base_dist(city_id);
CREATE INDEX city_weather_station_dist_index_city_id on city_weather_station_dist(city_id);
CREATE INDEX counties_index_id ON counties(id);
CREATE INDEX counties_index_lat_lon on counties(lat, lon);
CREATE UNIQUE INDEX counties_index_name_state_id ON counties(name, state_id);
CREATE INDEX counties_index_state_id ON counties(state_id);
CREATE INDEX military_bases_id ON military_bases(id);
CREATE INDEX military_bases_lat_lon ON military_bases(lat, lon);
CREATE INDEX shapes_index_id ON shapes(id);
CREATE INDEX sightings_index_city_id ON sightings(city_id);
CREATE INDEX sightings_index_id ON sightings(id);
CREATE INDEX sightings_index_occurred_at ON sightings(occurred_at);
CREATE INDEX sightings_index_shape_id ON sightings(shape_id);
CREATE INDEX states_index_id ON states(id);
CREATE UNIQUE INDEX states_index_lat_lon ON states(lat,lon);
CREATE INDEX states_index_name_abbreviation ON states(name_abbreviation);
CREATE INDEX weather_stations_index_id ON weather_stations(id);
CREATE INDEX weather_stations_index_lat_lon ON weather_stations(lat, lon);
SQL
	sql.strip.split(/;$/).each do |s| 
		execute(s) 
	end
  end

  def down
  	sql = <<'SQL'
DROP TABLE airports;
DROP TABLE cities;
DROP TABLE city_airport_dist;
DROP TABLE city_military_base_dist;
DROP TABLE city_weather_station_dist;
DROP TABLE counties;
DROP TABLE military_bases;
DROP TABLE shapes;
DROP TABLE sighting_types;
DROP TABLE sightings;
DROP TABLE states;
DROP TABLE weather_stations;
SQL
	sql.strip.split(/;$/).each do |s| 
		execute(s) 
	end
  end
end
