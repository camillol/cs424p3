# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20111101041934) do

  create_table "airports", :primary_key => "ID", :force => true do |t|
    t.string "name", :limit => nil
    t.string "city", :limit => nil
    t.float  "lat"
    t.float  "lon"
  end

  add_index "airports", ["ID"], :name => "airports_index_id"
  add_index "airports", ["lat", "lon"], :name => "airports_index_lat_lon"

  create_table "cities", :force => true do |t|
    t.integer "county_id"
    t.integer "state_id"
    t.string  "name",      :limit => nil
    t.float   "lat"
    t.float   "lon"
  end

  add_index "cities", ["county_id"], :name => "cities_index_county_id"
  add_index "cities", ["id"], :name => "cities_index_id"
  add_index "cities", ["lat", "lon"], :name => "cities_index_lat_lon"
  add_index "cities", ["name", "state_id"], :name => "cities_index_name_state_id", :unique => true
  add_index "cities", ["state_id"], :name => "cities_index_state_id"

  create_table "city_airport_dist", :id => false, :force => true do |t|
    t.integer "city_id"
    t.integer "airport_id"
    t.float   "distance"
  end

  add_index "city_airport_dist", ["city_id"], :name => "cadist_index_city_id"

  create_table "city_military_base_dist", :id => false, :force => true do |t|
    t.integer "city_id"
    t.integer "military_base_id"
    t.float   "distance"
  end

  add_index "city_military_base_dist", ["city_id"], :name => "city_military_base_dist_index_city_id"

  create_table "city_weather_station_dist", :id => false, :force => true do |t|
    t.integer "city_id"
    t.integer "weather_station_id"
    t.float   "distance"
  end

  add_index "city_weather_station_dist", ["city_id"], :name => "city_weather_station_dist_index_city_id"

  create_table "counties", :force => true do |t|
    t.integer "state_id"
    t.string  "name",               :limit => nil
    t.float   "population_density"
    t.float   "lat"
    t.float   "lon"
  end

  add_index "counties", ["id"], :name => "counties_index_id"
  add_index "counties", ["lat", "lon"], :name => "counties_index_lat_lon"
  add_index "counties", ["name", "state_id"], :name => "counties_index_name_state_id", :unique => true
  add_index "counties", ["state_id"], :name => "counties_index_state_id"

  create_table "military_bases", :primary_key => "ID", :force => true do |t|
    t.string "name", :limit => nil
    t.float  "lat"
    t.float  "lon"
  end

  add_index "military_bases", ["ID"], :name => "military_bases_id"
  add_index "military_bases", ["lat", "lon"], :name => "military_bases_lat_lon"

  create_table "shapes", :force => true do |t|
    t.string  "name",    :limit => nil
    t.integer "type_id"
  end

  add_index "shapes", ["id"], :name => "shapes_index_id"

  create_table "sighting_types", :force => true do |t|
    t.string  "name",     :limit => nil
    t.string  "img_name", :limit => nil
    t.integer "color"
  end

  create_table "sightings", :force => true do |t|
    t.integer   "city_id"
    t.integer   "shape_id"
    t.string    "summary_description", :limit => nil
    t.string    "full_description",    :limit => nil
    t.timestamp "occurred_at"
    t.timestamp "reported_at"
    t.timestamp "posted_at"
    t.integer   "temperature"
    t.string    "weather_conditions",  :limit => nil
  end

  add_index "sightings", ["city_id"], :name => "sightings_index_city_id"
  add_index "sightings", ["id"], :name => "sightings_index_id"
  add_index "sightings", ["occurred_at"], :name => "sightings_index_occurred_at"
  add_index "sightings", ["shape_id"], :name => "sightings_index_shape_id"

  create_table "states", :force => true do |t|
    t.string "name_abbreviation", :limit => nil
    t.string "name",              :limit => nil
    t.float  "lat"
    t.float  "lon"
  end

  add_index "states", ["id"], :name => "states_index_id"
  add_index "states", ["lat", "lon"], :name => "states_index_lat_lon", :unique => true
  add_index "states", ["name_abbreviation"], :name => "states_index_name_abbreviation"

  create_table "weather_stations", :force => true do |t|
    t.string  "name",     :limit => nil
    t.string  "key",      :limit => nil
    t.integer "state_id"
    t.float   "lat"
    t.float   "lon"
  end

  add_index "weather_stations", ["id"], :name => "weather_stations_index_id"
  add_index "weather_stations", ["lat", "lon"], :name => "weather_stations_index_lat_lon"

end
