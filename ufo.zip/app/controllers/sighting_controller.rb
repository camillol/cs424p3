class SightingController < ApplicationController

	def filterWhere yearMin, yearMax, monthMin, monthMax, hourMin, hourMax, activeTypes=nil
		where = ""
		where += "cast(strftime('%Y',occurred_at) as integer) >= #{yearMin} and " if yearMin > 2000
		where += "cast(strftime('%Y',occurred_at) as integer) <= #{yearMax} and " if yearMax < 2011
		where += "cast(strftime('%m',occurred_at) as integer) >= #{monthMin} and " if monthMin > 1
		where += "cast(strftime('%m',occurred_at) as integer) <= #{monthMax} and " if monthMax < 12
		where += "cast(strftime('%H',occurred_at) as integer) >= #{hourMin} and " if hourMin > 0
		where += "cast(strftime('%H',occurred_at) as integer) <= #{hourMax} and " if hourMax < 23
		
		if activeTypes != nil
			where += "type_id IN (" + activeTypes.join(",") + ") and "
		end
		
		where += " TRUE "
	end

	def counts
		params[:filter] =~ /(\d+)-(\d+) (\d+)-(\d+) (\d+)-(\d+) .*/
		yearMin, yearMax, monthMin, monthMax, hourMin, hourMax = [$1, $2, $3, $4, $5, $6].map{|x| x.to_i}
		
		query = "select cities.id"
		(1..7).each do |n|
			query += ", sum(case when type_id=#{n} then 1 else 0 end) as count_#{n}"
		end
		query += " from cities join sightings on sightings.city_id = cities.id join shapes on shape_id = shapes.id"
		query += " where " + filterWhere(yearMin, yearMax, monthMin, monthMax, hourMin, hourMax)
    	query += " group by cities.id"
    	
    	result = ActiveRecord::Base.connection.execute(query)
    	cities = []
    	result.each do |r|
    		cities << {
    			:id		=> r['id'],
    			:counts	=> (1..7).map{|n| r["count_#{n}"]}
    		}
		end
		
    	render :json => { :cities => cities }
	end
	
	def forCity
		params[:filter] =~ /(\d+)-(\d+) (\d+)-(\d+) (\d+)-(\d+) (.*)/
		yearMin, yearMax, monthMin, monthMax, hourMin, hourMax = [$1, $2, $3, $4, $5, $6].map{|x| x.to_i}
		activeTypes = $7.split(',')
		
		query = "select * from sightings join shapes on shape_id = shapes.id"
      	query += " where city_id = #{params[:id]} and "
      	query += filterWhere(yearMin, yearMax, monthMin, monthMax, hourMin, hourMax, activeTypes)
      	query += " order by occurred_at"
      	
      	result = ActiveRecord::Base.connection.execute(query)
    	sightings = []
    	result.each do |r|
    		sightings << {
    			:full_description		=> r['full_description'],
    			:type_id				=> r['type_id'],
    			:name					=> r['name'],
    			:occurred_at			=> r['occurred_at'],
    			:posted_at				=> r['posted_at'],
    			:weather_conditions		=> r['weather_conditions'],
    			:temperature			=> r['temperature'],
    		}
		end
		
    	render :json => { :sightings => sightings }
	end
	
	def intervalsCase(breaks, column)
		caseQuery = "when #{column} < #{breaks[0]} then 1 "
		(1..breaks.length-1).each do |i|
      		caseQuery += "when #{column} >= #{breaks[i-1]} and #{column} < #{breaks[i]} then #{(i+1)} "
		end
	    caseQuery += "else #{breaks.length+1}"
	end
	
	def countsByCategory
		airportsDistanceBreaks = [7.794978,12.22485,16.34988,21.02355,26.27319,32.03328,38.54012,45.20428,54.43778,64.34605,76.22255,91.7209,113.2127,152.5769]
		weatherStDistanceBreaks = [3.417465,5.244248,6.937217,8.564252,10.51355,12.41377,14.63627,16.98696,19.75864,23.02078,26.70035,31.42313,38.6634,50.20286]
		militaryBaseDistanceBreaks = [12.07392,20.41422,27.86664,36.02675,44.57247,54.70817,67.01115,80.2194,95.13276,111.2619,133.6569,158.7418,192.5056,247.0147]
		populationDensityBreaks = [470,1290,2150,3073.333,4136.667,5350,7173.333,10183.33,14460,25483,54829]
		
		morejoin = ""
		
		catName = params[:catName]
		if catName == "year"
			query = "select extract(year from occurred_at) as year"
		elsif catName == "month"
			query = "select extract(month from occurred_at) as month"
		elsif catName == "hour"
			query = "select extract(hour from occurred_at) as hour"
		elsif catName == "season"
			query = "select cast(extract(month from occurred_at) as integer) / 3 % 4 as season"
		elsif catName == "airport_dist"
			caseQuery = intervalsCase(airportsDistanceBreaks, "distance")
			query = "select case #{caseQuery} end as #{catName}"
			morejoin = "join city_airport_dist on sightings.city_id = city_airport_dist.city_id"
		elsif catName == "weather_dist"
			caseQuery = intervalsCase(weatherStDistanceBreaks, "distance")
			query = "select case #{caseQuery} end as #{catName}"
			morejoin = "join city_weather_station_dist on sightings.city_id = city_weather_station_dist.city_id"
		elsif catName == "military_dist"
			caseQuery = intervalsCase(militaryBaseDistanceBreaks, "distance")
			query = "select case #{caseQuery} end as #{catName}"
			morejoin = "join city_military_base_dist on sightings.city_id = city_military_base_dist.city_id"
		elsif catName == "pop_density"
			caseQuery = intervalsCase(populationDensityBreaks, "population_density")
			query = "select case #{caseQuery} end as #{catName}"
			morejoin = "join cities on sightings.city_id = cities.id join counties on cities.county_id = counties.id"
		end
		(1..7).each do |n|
			query += ", sum(case when type_id=#{n} then 1 else 0 end) as count_#{n}"
		end
      	query += " from sightings join shapes on shape_id = shapes.id #{morejoin} group by #{catName} order by #{catName}"
		
		result = ActiveRecord::Base.connection.execute(query)
    	buckets = []
    	result.each do |r|
    		buckets << {
    			catName => r[catName],
    			:counts	=> (1..7).map{|n| r["count_#{n}"]}
    		}
		end
		
    	render :json => { :buckets => buckets }
	end
	
	def byTime
		limit = params[:limit]
		offset = params[:offset]
		
		query = "select occurred_at, city_id, type_id from sightings left outer join shapes on shape_id = shapes.id"
      	query += " order by occurred_at limit #{limit} offset #{offset}"
      	
      	result = ActiveRecord::Base.connection.execute(query)
      	sightings = []
    	result.each do |r|
    		sightings << {
    			:occurred_at	=> r['occurred_at'],
    			:city_id		=> r['city_id'],
    			:type_id		=> r['type_id'],
    		}
		end
		
    	render :json => { :sightings => sightings }
	end
	
	def lastDate
		result = ActiveRecord::Base.connection.execute("select max(occurred_at) from sightings")
		render :text => result.getvalue(0,0)
	end

end
