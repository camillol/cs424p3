class MapController < ApplicationController

	def tile
		subdomains = ["otile1", "otile2", "otile3", "otile4"]
		template = "http://{S}.mqcdn.com/tiles/1.0.0/osm/{Z}/{X}/{Y}.png"
		uri = template.gsub("{X}", params[:x]).gsub("{Y}", params[:y]).gsub("{Z}", params[:z]).gsub("{S}", subdomains.sample)
		result = Net::HTTP.get_response(URI.parse(uri))
        render :text => result.body, :content_type => result["Content-Type"]
    end

end
