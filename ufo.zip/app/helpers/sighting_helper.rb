module SightingHelper
end
