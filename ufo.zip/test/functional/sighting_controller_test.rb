require 'test_helper'

class SightingControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
