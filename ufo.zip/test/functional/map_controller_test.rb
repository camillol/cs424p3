require 'test_helper'

class MapControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
