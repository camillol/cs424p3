require 'test_helper'

class SightingHelperTest < ActionView::TestCase
end
