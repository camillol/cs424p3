require 'test_helper'

class MapHelperTest < ActionView::TestCase
end
